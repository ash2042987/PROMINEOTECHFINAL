package com.finalPromineoTech.socialMediaAppFinal.repository;

import org.springframework.data.repository.CrudRepository;

import com.finalPromineoTech.socialMediaAppFinal.entity.Comment;

public interface CommentRepository  extends CrudRepository<Comment, Long>{

}
