package com.finalPromineoTech.socialMediaAppFinal.repository;

import org.springframework.data.repository.CrudRepository;

import com.finalPromineoTech.socialMediaAppFinal.entity.Post;

public interface PostRepository extends CrudRepository<Post, Long> {
	

}
