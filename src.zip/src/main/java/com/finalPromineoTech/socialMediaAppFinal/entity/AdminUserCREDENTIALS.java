package com.finalPromineoTech.socialMediaAppFinal.entity;

public class AdminUserCREDENTIALS {
		
		private String adminUserId;
		private String adminUserPassword;
		
		
		public String getAdminUserId() {
			return adminUserId;
		}
		
		public void setUserId(String adminUserId) {
			this.adminUserId = adminUserId;
		}
		
		public String getAdminUserPassword() {
			return adminUserPassword;
		}
		
		public void setAdminUserPassword(String adminUserPassword) {
			this.adminUserPassword = adminUserPassword;
		}
		
		
}
